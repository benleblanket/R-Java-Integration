package com.github.rcaller.scriptengine;



public class TestClass2 {

    public final int[] int_array = new int[]{1,2,3,4,5};
    public final double[] double_array = new double[]{1.0, 2.0, 9.0};
    public final String[] string_array = new String[]{"A","Z","X","H","h"};
    
}

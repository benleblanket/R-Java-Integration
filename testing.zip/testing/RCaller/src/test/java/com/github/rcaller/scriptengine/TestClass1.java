 
package com.github.rcaller.scriptengine;


public class TestClass1 {
    public double[] d1 = new double[]{1.0, 2.0, 3.0};
    public double[] d2 = new double[]{4.0, 5.0, 6.0};
}

package com.github.rcaller.graphics;

public enum GraphicsType {

    bmp,
    jpeg,
    tiff,
    png
}

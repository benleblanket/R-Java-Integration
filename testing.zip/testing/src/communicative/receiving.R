# Title     : TODO
# Objective : TODO
# Created by: Benjamin
# Created on: 6/5/2017

manipData <- function() {
    x <- 3
    x


}
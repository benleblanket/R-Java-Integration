package jUnit;

import org.junit.Test;

/**
 * Created by Benjamin on 6/5/2017.
 */
public class testR {

    @Test
    public void interactR(){

    }


}
